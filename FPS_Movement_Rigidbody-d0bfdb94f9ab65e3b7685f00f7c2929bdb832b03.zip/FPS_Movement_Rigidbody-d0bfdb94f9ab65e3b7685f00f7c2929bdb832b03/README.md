#### Simple FPS Movement

A simple movement system for Unity, based on rigidbodies.

[For setup and usage, use this tutorial](https://www.youtube.com/channel/UCn7E5qFz-BML6o7XnjtlytA?)
